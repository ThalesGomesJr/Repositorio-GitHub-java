import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;

public class SomCarta extends JFrame {
	
	JButton tocar = new JButton("");
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SomCarta() {//construtor
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(200,200);
		setLocationRelativeTo(null);
		setVisible(true);
		
		add(tocar);
		tocar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				play("carta");
			}
		});
		
	}
	
	
	public void play(String sound) {
		URL url = getClass().getResource(sound+".wav");
		AudioClip audio = Applet.newAudioClip(url);
		audio.play();
	}
	
	public static void main(String[] args) {
		new SomCarta();
	}

}
